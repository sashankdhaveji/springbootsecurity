package com.springboot.springbootdemo.util;

public enum UserRoleEnum {

    ADMIN_ROLE,USER_ROLE;

}
