package com.springboot.springbootdemo.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class SignupResponse {

    private String message;

    private List<ErrorData> errorDataList;

}
