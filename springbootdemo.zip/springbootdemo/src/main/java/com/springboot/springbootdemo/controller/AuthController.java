package com.springboot.springbootdemo.controller;

import com.springboot.springbootdemo.dto.LoginRequest;
import com.springboot.springbootdemo.dto.LoginResponse;
import com.springboot.springbootdemo.dto.SignUpRequest;
import com.springboot.springbootdemo.dto.SignupResponse;
import com.springboot.springbootdemo.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody @NotNull LoginRequest request) {
        LoginResponse loginResponse = authService.login(request);
        if(loginResponse.getErrorDataList()==null || loginResponse.getErrorDataList().isEmpty())
            return new ResponseEntity(loginResponse, HttpStatus.OK);
        else
            return new ResponseEntity(loginResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }



    @PostMapping("/signup")
    public ResponseEntity<LoginResponse> signup(@RequestBody @NotNull SignUpRequest request) {
        SignupResponse signupResponse = authService.signup(request);
        if(signupResponse.getErrorDataList()==null || signupResponse.getErrorDataList().isEmpty())
            return new ResponseEntity(signupResponse, HttpStatus.OK);
        else
            return new ResponseEntity(signupResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
