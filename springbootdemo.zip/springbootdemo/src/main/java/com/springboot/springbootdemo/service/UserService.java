package com.springboot.springbootdemo.service;

import com.springboot.springbootdemo.dao.UserRepository;
import com.springboot.springbootdemo.dto.AddressDto;
import com.springboot.springbootdemo.dto.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<UserDto> findAllUsers() {

        return userRepository.findAll().stream()
                .filter(Objects::nonNull)
                .map(user -> {
                    return UserDto.builder()
                            .address(AddressDto.builder()
                                    .country(user.getAddress().getCountry())
                                    .id(user.getAddress().getId())
                                    .state(user.getAddress().getState())
                                    .city(user.getAddress().getCity())
                                    .addressLine(user.getAddress().getAddressLine())
                                    .build())
                            .userName(user.getUserName())
                            .role(user.getRole())
                            .id(user.getId())
                            .build();
                }).collect(Collectors.toList());

    }

}
