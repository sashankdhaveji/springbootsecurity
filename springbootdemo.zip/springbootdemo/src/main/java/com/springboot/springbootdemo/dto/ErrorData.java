package com.springboot.springbootdemo.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorData {

    private String errorMessage;
    private int errorCode;
    private String description;

}
