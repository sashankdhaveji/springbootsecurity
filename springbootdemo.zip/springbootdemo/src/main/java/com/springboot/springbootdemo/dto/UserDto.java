package com.springboot.springbootdemo.dto;

import com.springboot.springbootdemo.util.UserRoleEnum;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserDto {

    private String userName;

    private Integer id;

    private String password;

    private AddressDto address;

    private UserRoleEnum role;

}
