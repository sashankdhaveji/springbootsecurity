package com.springboot.springbootdemo.dto;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class AddressDto {

    private Integer id;

    private String addressLine;

    private String city;

    private String state;

    private String country;

}
