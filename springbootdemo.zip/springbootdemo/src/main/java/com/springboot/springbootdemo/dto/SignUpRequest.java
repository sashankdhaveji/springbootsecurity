package com.springboot.springbootdemo.dto;

import com.springboot.springbootdemo.util.UserRoleEnum;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@Builder
public class SignUpRequest {

    @NotEmpty(message = "Username cannot be empty")
    private String userName;

    @NotEmpty(message = "Password cannot be empty")
    private String password;

    @NotNull(message = "Enter Address details")
    private AddressDto address;

}
