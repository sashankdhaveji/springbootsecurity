package com.springboot.springbootdemo.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table
@Data
public class Address {

    @Column
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(nullable = false)
    private String addressLine;

    @Column(nullable = false)
    private String city;

    @Column(nullable = false)
    private String state;

    @Column(nullable = false)
    private String country;

    @OneToOne(mappedBy = "address" , fetch = FetchType.LAZY)
    private User user;

}
