package com.springboot.springbootdemo.entity;

import com.springboot.springbootdemo.util.UserRoleEnum;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "user_demo")
@Data
public class User {

    @Column(nullable = false,unique = true)
    private String userName;

    @Column
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(nullable = false)
    private String password;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "address_id",nullable = false, referencedColumnName = "id")
    private Address address;

    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private UserRoleEnum role;

}
