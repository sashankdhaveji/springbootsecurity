package com.springboot.springbootdemo.service;

import com.springboot.springbootdemo.dao.UserRepository;
import com.springboot.springbootdemo.dto.*;
import com.springboot.springbootdemo.entity.Address;
import com.springboot.springbootdemo.entity.User;
import com.springboot.springbootdemo.jwt.JwtTokenUtil;
import com.springboot.springbootdemo.jwt.JwtUserDetailsService;
import com.springboot.springbootdemo.util.UserRoleEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Objects;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private JwtUserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public LoginResponse login(final LoginRequest request) {

        try {
            User user = userRepository.findByUserName(request.getUserName());
            if (Objects.nonNull(user)) {
                authenticate(request.getUserName(), request.getPassword());

                final UserDetails userDetails = userDetailsService
                        .loadUserByUsername(request.getUserName());

                final String token = jwtTokenUtil.generateToken(userDetails);
                return LoginResponse.builder().message("Successful Login").jwt(token).build();
            }
            else
                return LoginResponse.builder().errorDataList(
                        Arrays.asList(new ErrorData[]{ErrorData.builder().errorCode(-1).errorMessage("Invalid Login").build()})
                ).build();
        } catch (Exception e) {
            return LoginResponse.builder()
                    .errorDataList(Arrays.asList(ErrorData.builder()
                            .errorMessage("Exception!").errorCode(500).description(e.getMessage()).build())).build();
        }

    }

    private void authenticate(String username, String password) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        } catch (DisabledException e) {
            throw new Exception("USER_DISABLED", e);
        } catch (BadCredentialsException e) {
            throw new Exception("INVALID_CREDENTIALS", e);
        }
    }

    public SignupResponse signup(final SignUpRequest request) {
        try {

            if(userRepository.existsByUserName(request.getUserName()))
                return SignupResponse.builder().errorDataList(
                        Arrays.asList(new ErrorData[]{ErrorData.builder()
                                .errorMessage("User Already exists").errorCode(-2)
                                .description("Duplicate user found").build()})
                ).build();

            User user = new User();
            user.setUserName(request.getUserName());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            user.setRole(UserRoleEnum.USER_ROLE);

            Address address = new Address();
            address.setAddressLine(request.getAddress().getAddressLine());
            address.setCity(request.getAddress().getCity());
            address.setState(request.getAddress().getState());
            address.setCountry(request.getAddress().getCountry());

            user.setAddress(address);

            userRepository.save(user);

            return SignupResponse.builder().message("User Created Successfully!").build();
        } catch (Exception e) {
            return SignupResponse.builder().errorDataList(
                    Arrays.asList(new ErrorData[]{ErrorData.builder()
                            .errorMessage("Error while creating the user").errorCode(-1)
                            .description(e.getMessage()).build()})
            ).build();
        }

    }
}
